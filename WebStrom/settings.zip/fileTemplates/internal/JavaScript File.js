/**
* 功能描述：
* 创建日期：${YEAR} 年 ${MONTH} 月 ${DAY} 日
*/

// 使用严格模式
'use strict';