/**
 * 作者：flowerwine
 * 创建日期：${YEAR} 年 ${MONTH} 月 ${DAY}
 */
 // 使用严格模式
 'use strict';