#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
*  @date ${YEAR} 年 ${MONTH} 月 ${DAY} 日
*  @author flowerwine
*/  
public interface ${NAME} {
}
